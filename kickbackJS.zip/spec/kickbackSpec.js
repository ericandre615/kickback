describe('kickback', function() {
    describe('it should have a method request', function() {
        expect(String.prototype.request).toBeDefined();
    });
});
